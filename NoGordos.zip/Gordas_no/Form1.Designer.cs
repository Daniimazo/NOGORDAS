﻿namespace Gordas_no
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_controlp = new System.Windows.Forms.Label();
            this.lbl_peso = new System.Windows.Forms.Label();
            this.lbl_estatura = new System.Windows.Forms.Label();
            this.txt_peso = new System.Windows.Forms.TextBox();
            this.txt_estatura = new System.Windows.Forms.TextBox();
            this.button_calcular = new System.Windows.Forms.Button();
            this.button_limpiar = new System.Windows.Forms.Button();
            this.lbl_message = new System.Windows.Forms.Label();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.gb_genero = new System.Windows.Forms.GroupBox();
            this.rb_female = new System.Windows.Forms.RadioButton();
            this.rb_male = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.gb_genero.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_controlp
            // 
            this.lbl_controlp.AutoSize = true;
            this.lbl_controlp.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lbl_controlp.Font = new System.Drawing.Font("Bell MT", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_controlp.Location = new System.Drawing.Point(156, 9);
            this.lbl_controlp.Name = "lbl_controlp";
            this.lbl_controlp.Size = new System.Drawing.Size(140, 24);
            this.lbl_controlp.TabIndex = 0;
            this.lbl_controlp.Text = "Control de peso";
            // 
            // lbl_peso
            // 
            this.lbl_peso.AutoSize = true;
            this.lbl_peso.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_peso.Font = new System.Drawing.Font("Bell MT", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_peso.Location = new System.Drawing.Point(25, 101);
            this.lbl_peso.Name = "lbl_peso";
            this.lbl_peso.Size = new System.Drawing.Size(137, 24);
            this.lbl_peso.TabIndex = 1;
            this.lbl_peso.Text = "Ingrese su peso";
            // 
            // lbl_estatura
            // 
            this.lbl_estatura.AutoSize = true;
            this.lbl_estatura.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_estatura.Font = new System.Drawing.Font("Bell MT", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_estatura.Location = new System.Drawing.Point(254, 101);
            this.lbl_estatura.Name = "lbl_estatura";
            this.lbl_estatura.Size = new System.Drawing.Size(167, 24);
            this.lbl_estatura.TabIndex = 2;
            this.lbl_estatura.Text = "Ingrese su estatura";
            // 
            // txt_peso
            // 
            this.txt_peso.Location = new System.Drawing.Point(29, 128);
            this.txt_peso.Name = "txt_peso";
            this.txt_peso.Size = new System.Drawing.Size(163, 20);
            this.txt_peso.TabIndex = 3;
            // 
            // txt_estatura
            // 
            this.txt_estatura.Location = new System.Drawing.Point(258, 128);
            this.txt_estatura.Name = "txt_estatura";
            this.txt_estatura.Size = new System.Drawing.Size(163, 20);
            this.txt_estatura.TabIndex = 4;
            // 
            // button_calcular
            // 
            this.button_calcular.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_calcular.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_calcular.Font = new System.Drawing.Font("Bell MT", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_calcular.Location = new System.Drawing.Point(29, 371);
            this.button_calcular.Name = "button_calcular";
            this.button_calcular.Size = new System.Drawing.Size(163, 40);
            this.button_calcular.TabIndex = 5;
            this.button_calcular.Text = "CALCULAR";
            this.button_calcular.UseVisualStyleBackColor = false;
            this.button_calcular.Click += new System.EventHandler(this.button_calcular_Click);
            // 
            // button_limpiar
            // 
            this.button_limpiar.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_limpiar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_limpiar.Font = new System.Drawing.Font("Bell MT", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_limpiar.Location = new System.Drawing.Point(258, 371);
            this.button_limpiar.Name = "button_limpiar";
            this.button_limpiar.Size = new System.Drawing.Size(163, 40);
            this.button_limpiar.TabIndex = 6;
            this.button_limpiar.Text = "LIMPIAR";
            this.button_limpiar.UseVisualStyleBackColor = false;
            this.button_limpiar.Click += new System.EventHandler(this.button_limpiar_Click);
            // 
            // lbl_message
            // 
            this.lbl_message.AutoSize = true;
            this.lbl_message.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_message.Font = new System.Drawing.Font("Bell MT", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_message.Location = new System.Drawing.Point(37, 66);
            this.lbl_message.Name = "lbl_message";
            this.lbl_message.Size = new System.Drawing.Size(0, 24);
            this.lbl_message.TabIndex = 7;
            // 
            // pictureBox
            // 
            this.pictureBox.ErrorImage = null;
            this.pictureBox.Location = new System.Drawing.Point(190, 164);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(231, 191);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox.TabIndex = 8;
            this.pictureBox.TabStop = false;
            // 
            // gb_genero
            // 
            this.gb_genero.Controls.Add(this.rb_female);
            this.gb_genero.Controls.Add(this.rb_male);
            this.gb_genero.Font = new System.Drawing.Font("Bell MT", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_genero.Location = new System.Drawing.Point(27, 214);
            this.gb_genero.Name = "gb_genero";
            this.gb_genero.Size = new System.Drawing.Size(135, 89);
            this.gb_genero.TabIndex = 9;
            this.gb_genero.TabStop = false;
            this.gb_genero.Text = "Genero";
            // 
            // rb_female
            // 
            this.rb_female.AutoSize = true;
            this.rb_female.Location = new System.Drawing.Point(7, 58);
            this.rb_female.Name = "rb_female";
            this.rb_female.Size = new System.Drawing.Size(110, 28);
            this.rb_female.TabIndex = 1;
            this.rb_female.TabStop = true;
            this.rb_female.Text = "Femenino";
            this.rb_female.UseVisualStyleBackColor = true;
            // 
            // rb_male
            // 
            this.rb_male.AutoSize = true;
            this.rb_male.Location = new System.Drawing.Point(7, 28);
            this.rb_male.Name = "rb_male";
            this.rb_male.Size = new System.Drawing.Size(114, 28);
            this.rb_male.TabIndex = 0;
            this.rb_male.TabStop = true;
            this.rb_male.Text = "Masculino";
            this.rb_male.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(443, 450);
            this.Controls.Add(this.gb_genero);
            this.Controls.Add(this.pictureBox);
            this.Controls.Add(this.lbl_message);
            this.Controls.Add(this.button_limpiar);
            this.Controls.Add(this.button_calcular);
            this.Controls.Add(this.txt_estatura);
            this.Controls.Add(this.txt_peso);
            this.Controls.Add(this.lbl_estatura);
            this.Controls.Add(this.lbl_peso);
            this.Controls.Add(this.lbl_controlp);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "CONTROL DE PESO";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.gb_genero.ResumeLayout(false);
            this.gb_genero.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_controlp;
        private System.Windows.Forms.Label lbl_peso;
        private System.Windows.Forms.Label lbl_estatura;
        private System.Windows.Forms.TextBox txt_peso;
        private System.Windows.Forms.TextBox txt_estatura;
        private System.Windows.Forms.Button button_calcular;
        private System.Windows.Forms.Button button_limpiar;
        private System.Windows.Forms.Label lbl_message;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.GroupBox gb_genero;
        private System.Windows.Forms.RadioButton rb_female;
        private System.Windows.Forms.RadioButton rb_male;
    }
}

