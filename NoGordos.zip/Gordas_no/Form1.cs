﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gordas_no
{
    public partial class Form1 : Form
    {
        private SoundPlayer player; // Campo para el SoundPlayer

        public Form1()
        {
            InitializeComponent();

            rb_female.Checked = false;
            rb_male.Checked = true;
            player = null; // Inicializar el campo
        }

        public void Limpiar()
        {
            txt_estatura.Text = string.Empty;
            txt_peso.Text = string.Empty;
            pictureBox.Image = null;
            lbl_message.Text = string.Empty;
            rb_female.Checked = false;
            rb_male.Checked = true;

            // Detener el sonido si está reproduciéndose
            if (player != null)
            {
                player.Stop(); // Detener el sonido
            }
        }

        private void button_limpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        public void Mensajes()
        {
            if (string.IsNullOrWhiteSpace(txt_estatura.Text) || string.IsNullOrWhiteSpace(txt_peso.Text))
            {
                lbl_message.ForeColor = Color.Red;
                lbl_message.Text = "Ingrese todos los campos obligatorios";
                return;
            }

            double peso = Convert.ToDouble(txt_peso.Text);
            double estatura = Convert.ToDouble(txt_estatura.Text);

            double imc = peso / (estatura * estatura);

            // Detener el sonido si ya hay uno reproduciéndose
            if (player != null)
            {
                player.Stop();
            }

            if (imc < 18.5 && rb_female.Checked)
            {
                lbl_message.ForeColor = Color.Red;
                lbl_message.Text = "Esta en lo huesos mija";
                pictureBox.Image = Properties.Resources.Bajo_peso;
                player = new SoundPlayer(Properties.Resources.what_bottom_text_meme_sanctuary_guardian_sound_effect_hd);
                player.Play();

            }
            else if (imc <= 18.5 && rb_male.Checked)
            {
                lbl_message.ForeColor = Color.Red;
                lbl_message.Text = "Esta en lo huesos mijo";
                pictureBox.Image = Properties.Resources.Bajo_peso;
                player = new SoundPlayer(Properties.Resources.what_bottom_text_meme_sanctuary_guardian_sound_effect_hd);
                player.Play();
            }
            else if (imc >= 18.5 && imc <= 24.9 && rb_female.Checked)
            {
                lbl_message.ForeColor = Color.Green;
                lbl_message.Text = "Estas rica mami";
                pictureBox.Image = Properties.Resources.Peso_ideal;
                player = new SoundPlayer(Properties.Resources.el_senor_de_la_noche_don_omar);
                player.Play();
            }
            else if (imc >= 18.5 && imc <= 24.9 && rb_male.Checked)
            {
                lbl_message.ForeColor = Color.Green;
                lbl_message.Text = "Estas rico papi";
                pictureBox.Image = Properties.Resources.Peso_ideal;
                player = new SoundPlayer(Properties.Resources.el_senor_de_la_noche_don_omar);
                player.Play();
            }
            else if (imc >= 25 && rb_female.Checked)
            {
                lbl_message.ForeColor = Color.Red;
                lbl_message.Text = "Ponte pilas con el GYM mami";
                pictureBox.Image = Properties.Resources.Sobre_peso;
                player = new SoundPlayer(Properties.Resources._999_social_credit_siren);
                player.Play();
            }
            else if (imc >= 25 && rb_male.Checked)
            {
                lbl_message.ForeColor = Color.Red;
                lbl_message.Text = "Ponte pilas con el GYM papi";
                pictureBox.Image = Properties.Resources.Sobre_peso;
                player = new SoundPlayer(Properties.Resources._999_social_credit_siren);
                player.Play();
            }
        }

        private void button_calcular_Click(object sender, EventArgs e)
        {
            Mensajes();
        }
    }
}
